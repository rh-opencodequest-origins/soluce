package io.quarkus.workshop.fight;

public record FightResult(String winner, String narration) {
}
